<?php $__env->startSection('content'); ?>
	<div class="row justify-content-md-center m-t-75">
		<div class="col-12 col-md-6">
			<div id="venta">
				<div class="row m-b-50 align-items-center">
					<div class="col-2">
						<button class="btn btn-primary" v-on:click="bajarVenta()"><i class="fas fa-backward fa-3x"></i></button>
						<span v-show="error_bajar" class="text-danger">{{ error_bajar }}</span>
					</div>
					<div class="col-2">
						<button class="btn btn-primary" v-on:click="subirVenta()"><i class="fas fa-forward fa-3x"></i></button>
						<span v-show="error_subir" class="text-danger">{{ error_subir }}</span>
					</div>
					<div class="col-2">
						<button class="btn btn-danger" v-on:click="eliminarVenta()"><i class="fas fa-eraser fa-3x"></i></button>
					</div>
					<div class="col-6">
						<ul class="list-group">
							<li class="list-group-item">Nombre: <strong>{{ venta_actual.name }}</strong></li>
							<li class="list-group-item">Precio: <strong>${{ venta_actual.price }}</strong></li>
							<li class="list-group-item">Restantes: <strong>{{ venta_actual.stock }}</strong></li>
						</ul>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<input type="text" v-model="codigo_barras" id="codigo_barras" v-on:keyup.enter="nuevaVenta()" placeholder="Codigo de barras" class="form-control focus-red">
						<!-- <span v-show="error_cb" class="text-danger">{{ error_cb }}</span> -->
					</div>
				</div>
				<!-- <div class="row m-t-10 m-b-10">
					<div class="col-12">
						<div class="card">
							<div class="card-header">
								Venta suelta
							</div>
							<div class="card-body">
								<form>
									<div class="form-group">
										<label for="nombre-articulo">Nombre</label>
										<input type="email" id="nombre-articulo" class="form-control" aria-describedby="emailHelp" placeholder="Nombre del articulo">
									</div>
									<div class="form-group">
										<label for="precio">Precio</label>
										<input type="text" id="precio" class="form-control" aria-describedby="emailHelp" placeholder="Nombre del articulo">
									</div>
									<button type="submit" class="btn btn-primary">Venta</button>
								</form>
							</div>
						</div>
					</div>
				</div> -->
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\kiosco2\resources\views/main/venta.blade.php ENDPATH**/ ?>
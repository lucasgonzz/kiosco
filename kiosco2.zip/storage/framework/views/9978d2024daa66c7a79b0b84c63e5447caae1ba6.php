<div class="modal fade" id="nuevo-mayorista" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Nuevo Mayorista</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="text" name="" class="form-control" v-model="mayorista" placeholder="Nombre del mayorista">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="button" class="btn btn-primary" v-on:click="saveMayorista">Guardar</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\wamp64\www\kiosco2\resources\views/main/modals/nuevoMayorista.blade.php ENDPATH**/ ?>
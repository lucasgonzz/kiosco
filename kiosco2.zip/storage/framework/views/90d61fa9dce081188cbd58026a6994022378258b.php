<?php $__env->startSection('content'); ?>
<div class="cont m-t-30">
    <div id="nuevo-articulo">

		<div class="row">
			<div class="col-12 col-md-6 offset-md-3">				
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<label for="codigo_barras">Codigo de Barras</label>
					<input type="text" id="codigo_barra" name="codigo_barras" class="form-control focus-red" v-model="codigo_barra" v-on:change="isRegister()" autofocus>
				</div>
				<div class="row m-b-5">
					<div class="col">
						<label for="cost">Costo</label>
						<input type="text" name="cost" class="form-control focus-red" v-model="cost">
					</div>
					<div class="col">
						<label for="price">Precio</label>
						<input type="text" name="price" class="form-control focus-red" v-model="price">
					</div>
				</div>
				<div class="form-group">
					<label for="name">Nombre</label>
					<input type="text" name="name" class="form-control focus-red" v-model="name">
				</div>
				<div class="form-group">
					<label for="created_at">Fecha</label>
					<input type="date" name="created_at" class="form-control focus-red" v-model="created_at">
				</div>
				<div class="row m-b-15">
					<div class="col">
						<label for="mayorista">Mayorista</label>
						<select class="form-control focus-red" name="mayorista" v-model="mayorista">
							<option v-for="mayorista in mayoristas">{{ mayorista.name }}</option>
						</select>
						<a href="#" v-on:click.prevent="addMayorista()">Añadir mayorista</a>
					</div>
					<div class="col">
						<label for="stock">Cantidad</label>
						<input type="text" name="stock" class="form-control focus-red" v-model="stock">
					</div>
				</div>
				<div class="form-group">
					<button type="button" v-on:click="newArticle()" class="btn btn-primary btn-lg btn-block focus-red">Guardar</button>
				</div> 
			</div>
		</div>
	<?php echo $__env->make('main.modals.nuevoMayorista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('main.modals.editarArticulo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\kiosco2\resources\views/main/ingresar.blade.php ENDPATH**/ ?>
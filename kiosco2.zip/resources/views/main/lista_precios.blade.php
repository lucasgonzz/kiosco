@extends('app')
@section('content')
<div id="lista-precios">
	<div class="row m-t-20">
		<div class="col-12">
			<div class="card">
				<div class="card-header h4">
					Seleccione criterios de busqueda
				</div>
				<div class="card-body"> 
					<div v-if="!buscar">
						<form>
							<div class="form-row align-items-start">
								<div class="col-12 m-b-20 m-lg-b-0 col-lg-4">
									<div class="form-check form-check-inline">
										<b-radio type="radio" v-model="filtrar" name="filtrar" native-value="no" id="mostrar-todos">Mostrar todos los artículos</b-radio>
									  	<!-- <input class="form-check-input" type="radio" id="mostrar-todos" name="filtrar" v-model="filtrar" value="no">
									  	<label class="form-check-label" for="mostrar-todos">Mostrar todos los artículos</label> -->
									</div>
									<div class="form-check form-check-inline">
										<b-radio type="radio" v-model="filtrar" name="filtrar" native-value="si" id="mostrar-lo-que">Mostrar lo que</b-radio>
										  <!-- <input class="form-check-input" type="radio" name="filtrar" id="mostrar-los-que" v-model="filtrar" value="si">
										  <label class="form-check-label" for="mostrar-los-que">Mostrar lo que</label> -->
									</div>
									<div v-show="filtrar == 'si'" class="m-t-10">
										<select v-model="filtro" name="filto" id="filtro" class="form-control">
											<option value="0">Tengan 1 en stock</option>
											<option value="1">No tengan stock</option>
											<option value="2">Esten desactualizados</option>
										</select>
									</div>
								</div>
								<div class="col-12 m-b-20 m-lg-b-0 col-lg-2">
									<label for="orden">Ordenar por</label>
									<select v-model="orden" name=orden" id="orden" class="form-control">
										<option value="0" selected>Mas viejos</option>
										<option value="1">Mas nuevos</option>
										<option value="2">Menor precio</option>
										<option value="3">Mayor precio</option>
										<option value="4">Mayorista</option>
									</select>
								</div>
								<div class="col-12 m-b-20 m-lg-b-0 col-lg-2">
									<label for="orden">Precio entre</label>
									<div>
										<input v-model="min" class="form-control input-precio" type="text" placeholder="Min"> - <input v-model="max" class="form-control input-precio" type="text" placeholder="Max">
									</div>
								</div>
								<div class="col-12 m-b-20 m-lg-b-0 col-lg-2">
									<label for="orden m-b-10">Elementos por página</label>
									<input type="number" min="0" v-model="perPage" class="form-control">
									<small class="form-text text-muted">Deje 0 si quiere mostrar todos</small>
								</div>
							</div>
							<div class="form-row align-items-start">
								<div class="col-12 col-lg-6 align-self-center">
									<button class="btn btn-primary btn-lg d-none d-lg-block" @click.prevent="getArticulos(1)"><i class="fas fa-check m-r-5 btn-icon"></i>Mostrar</button>
									<button class="btn btn-primary btn-lg btn-block d-lg-none" @click.prevent="getArticulos(1)">Mostrar</button>
								</div>
							</div>
						</form>
					</div>

				</div>
			</div>
		</div>
	</div>
	<div class="row m-t-30">
		<div class="col-12">
			<div class="card">
				<div class="card-header">
					<input class="form-check-input d-none" type="checkbox" v-model="buscar" id="defaultCheck1">
					<label class="form-check-label c-p" for="defaultCheck1">
						<h5 class="h4">
							<i v-if="buscar" class="fas fa-caret-up"></i>
							<i v-else class="fas fa-caret-down"></i>
							O busque por
						</h5>
					</label>
				</div>
				<div class="card-body">
					<div v-if="buscar">
						<form>
							<div class="form-row m-t-20">
								<div class="col-12 col-lg-3 m-b-20 m-lg-b-0">
									<label for="buscar-nombre">Nombre</label>
									<input type="text" v-model="nombre" id="buscar-nombre" class="form-control" placeholder="Nombre a buscar" autofocus>
								</div>
								<div class="col-12 col-lg-3 m-b-20 m-lg-b-0">
									<label for=buscar-codigo">Codigo de barras</label>
									<input type="text" v-model="codigo" id="buscar-codigo" placeholder="Codigo de barras" class="form-control" autofocus>
								</div>
								<div class="col-12 col-lg-2 m-b-20 m-lg-b-0">
									<label for="orden">Mayorista</label>
									<select multiple v-model="mayoristas" name=orden" id="orden" class="form-control">
										<option value="0" selected>Todos</option>
										<option v-for="mayorista in mayoristas_lista">@{{ mayorista.name }}</option>
									</select>
								</div>
							</div>
							<div class="form-row m-t-20">
								<div class="col-12 col-lg-3">
									<button class="btn btn-primary btn-lg d-none d-lg-block" v-on:click.prevent="search()"><i class="fas fa-search m-r-10"></i>Buscar</button>
									<button class="btn btn-primary btn-block d-lg-none m-t-10" v-on:click.prevent="search()"><i class="fas fa-search"></i>Buscar</button>
								</div>
							</div>							
						</form>
					</div>
				</div>
			</div>
		</div> <!-- .col -->
	</div> <!-- .row -->
	<hr class="m-t-5 m-b-5">
	<div class="row m-t-20">
		<div class="col">
			<p v-if="current_page == 0 && articulos.length"><strong>@{{ articulos.length }} articulos encontrados</strong></p>
			<p v-else><strong>@{{ pagination.total }} articulos encontrados</strong></p>
		</div>
	</div>
	<div class="row m-t-5">
		<div class="col-12 col-lg-6 m-t-5">
			<button type="button" class="btn btn-primary" v-on:click="getSearches()">
				Busquedas de hoy
			</button>
			<button type="button" class="btn btn-primary" v-on:click="getUltimosActualizados()">
				Ultimos actualizados
			</button>
			@include('main.modals.busquedas')
			@include('main.modals.ultimosActualizados')
		</div>
		<!-- <div class="col-12 col-md-6">
			<p v-show="noEncontrado">@{{ noEncontrado }}</p>
			<p>Buscado por: <strong>@{{ filtrado }}</strong></p>
			<p v-show="articulosEncontrados">Artículos encontrados: <strong>@{{ articulosEncontrados }}</strong></p>
		</div> -->
	</div>
	<div class="row p-r">
		<div class="col">
			<table class="table table-striped table-hover table-sm m-t-20">
				<thead class="thead-dark">
					<tr>
						<th scope="col">ID</th>
						<th scope="col">Codigo</th>
						<th scope="col">Ingreso</th>
						<th scope="col">Nombre</th>
						<th scope="col">Mayorista</th>
						<th class="col-precio">Precio</th>
						<th scope="col">Ingreso</th>
						<th scope="col">Costo</th>
						<th scope="col">Ult. Act</th>
						<th scope="col">Precio anterior</th>
						<th scope="col">Stock</th>
						<th scope="col" colspan="3" class="text-center">Opciones</th>
					</tr>
				</thead>
				<tbody>						
					<tr v-for="articulo in articulos" v-bind:class="articulo.style">
						<td>@{{ articulo.id }}</td>
						<td>@{{ articulo.codigo_barras }}</td>
						<td>@{{ articulo.creado }}</td>
						<td>@{{ articulo.name }}</td>
						<td>@{{ articulo.mayorista }}</td>
						<td class="precio">$@{{ articulo.price }}</td>
						<td>@{{ articulo.creado }}</td>
						<td>@{{ articulo.cost }}</td>
						<td>@{{ articulo.actualizado }}</td>
						<td>@{{ articulo.previus_price!=0 ? articulo.previus_price : ''}}</td>
						<td>@{{ articulo.stock }}</td>
						<td><a href="#" v-if="articulo.sales.length" class="btn btn-primary" v-on:click.prevent="showVentasAnteriores(articulo)"><i class="fas fa-shopping-cart m-r-5"></i>Ventas</a></td>
						<td><a href="#" class="btn btn-primary" v-on:click.prevent="editArticulo(articulo)"><i class="far fa-edit m-r-5"></i>Actualizar</a></td>
						<td><a href="#" class="btn btn-danger" v-on:click.prevent="deleteArticulo(articulo)"><i class="fas fa-trash m-r-5"></i>Borrar</a></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="spinner-border text-primary" id="cargando-estados" role="status">
		  	<span class="sr-only">Cargando...</span>
		</div>
	</div>
	<div v-show="current_page != 0">
		@include('main.modals.pagination')
	</div>
	
	<!-- <button class="scrollup">Arriba</button> -->
	@include('main.modals.editarArticulo')
	@include('main.modals.ventasAnteriores')
</div>
@endsection
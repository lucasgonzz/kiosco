<?php
	
namespace App\Helpers;

class DateFormat{

	public static function format($array, $format, $extras = null, $atributes = ['creado', 'actualizado']){
		// if($extras != null){
		// 	return [
		// 		'rta' => 'viene con algo',
		// 		'contenido' => $extras['name']
		// 	];
		// }else{
		// 	return [
		// 		'rta' => 'viene vacio'
		// 	];
		// }
		foreach ($array as $value) {
			$value->{$atributes[0]} = date_format($value->created_at, $format);
			$value->{$atributes[1]} = date_format($value->updated_at, $format);
			if(!is_null($extras)){
				$value{$extras['name']} = date_format($value->{$extras['value']}, $extras['format']);
			}
		}
		return $array;
	}
}